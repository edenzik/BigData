﻿Hadoop01: Nick Cummins, Kahlil Oppenheimer, Eden Zik, and Michael Partridge
Assignment 3
11/7/2014


Before doing anything else we first filtered the Amazon reviews for better clustering. The pre-processing was performed by two classes, StopWordUtility and StopFilter. The former class creates statistics about the words, including sorting all words in descending order of frequency across all reviews. The StopFilter class cleans the text and filters stop words based on matches with a text file created by StopWordUtility. The StopWordUtility class was performed off of the cluster environment, and so you may notice some constructs exclusive to Java 1.7 and later such as Try-With-Resources not present in the rest of our code for compliance with Hadoop and Mahout. The pre-processing steps took approximately 15 minutes to run on the entire data set and reduced the size of the data from just over 1GB to just under 600MB. As you can see in StopWordUtility, we finally filtered the 0.02% most frequent words (traditional stop words, mostly) and the 1% least frequent words (mostly misspelled or invented words not likely to provide useful).


Then, as per instruction, we converted the reviews into Mahout sequence files using a modification of the code posted in the tutorial (this code can be found in SeqPrep.java).  This file was executed exactly per the instructions in the tutorial (ie repackaged in the appropriate jar and run from there).  Once the sequence files were created we used the command line to create TF/IDF vectors of single, bi, tri, and tetragrams with the following command:


mahout/bin/mahout seq2sparse -i filtered_seq -o <output file> -wt tfidf -ng <n gram size> --maxDFPercent 85.


The initial conversion to sequence vectors took about 30 minutes, with each conversion to TF/IDF vectors taking between 20 and 50 minutes, based on both the n gram complexity and current server traffic.  Once we had the necessary vectors, we began generating K-means and Fuzzy K-means clusters.


We wrote some scripts to try and test different parameter values for k-means and fuzzy k-means. The scripts are uploaded and are called kmeans.sh (to run one k-means and fuzzy k-means job) and kmeans_test.sh (to run multiple k-means and fuzzy k-means jobs).


KMEANS:


We ran different combinations of k-means with differing convergence deltas, n-gram results, and even distance measures to ensure that we got the best results that we could. Our final run ended up having these parameters:


convergence delta: .005
n-gram: 1
distance measure: cosine


mahout/bin/mahout kmeans -i filtered_tfidf/l2_1gram/tfidf-vectors/ -c clusters_1 -o edentest/test_2 -cd 0.005 -x 10 -k 10 -cl -ow




FKMEANS:


We ran the same combinations that we ran on k-means to achieve the best fuzzy k-means results that we could. The only difference is that we added an observation of differing “fuzziness factors” for fuzzy k-means. Our final run ended up having these parameters:


convergence delta: .005
n-gram: 1
distance measure: cosine
fuzziness factor: 1.01


mahout/bin/mahout fkmeans -i filtered_tfidf/l2_1gram/tfidf-vectors/ -c clusters_1 -o eden_clustering_output/fkmeans_run_1_1grams -cd .005 -x 10 -k 10 -cl -ow -m 1.01


CLUSTERDUMP:


Running clusterdump was automated by the kmeans.sh script and filled in all of the paths nicely for us.


mahout/bin/mahout clusterdump -d filtered_tfidf/l2_1gram/dictionary.file-0 -dt sequencefile -i clustering_output/fkmeans_run_1_1_ngrams/clusters-2-final -n 10 -b 100 -o clusterdump_output/fkmeans_cd.05_x10_1gram_m1.5




END:


The final portion of the assignment was to once again map the data points back to the clusters that they were closest to. We used readKmeans class to read in the cluster centers for both kmeans and fuzzy kmeans (same code is used) and build maps. Those maps are used in ClusterPointMapper to find the points which have the most terms in common with the top ten terms for each cluster center. The closest cluster center is reported in our kmeans output. For fuzzy kmeans, we used the distance for those top ten terms (different clustering, of course) and computed the likelihood (normalized to 1) that a point belonged to any cluster. We printed those likelihoods out in descending order, per instructions.


Occasionally, a point had no terms in common with any of the fuzzy cluster centers. Initially this created NaN double values because the normalization failed, so you will observe a check that the sets a 0 total probability to 1 to correct that error. This will not significantly affect our results because those points did not correlate well with any cluster anyway and so all of their probabilities are listed as 0.


To run that utility and report cluster data for both kmeans and fuzzy kmeans, we used the following command:


java -cp Assignment3-0.0.1-SNAPSHOT.jar hadoop01.utils.ClusterPointMapper /home/hadoop01/clusterdump_output/final_output/kmeans_cd.005_x10_1gram_dmCosine.out /home/hadoop01/clusterdump_output/final_output/fkmeans_cd.005_x10_1gram_dmCosine_m1.01.out miketest/input_filtered_pa3_random.txt


EXTRA:


Although we were not able to successfully complete any internal cluster evaluation, the source we attempted to use is included in ClusterEval.java. We were unable to determine the correct types of vectors in the sequence files (NamedVector, RandomAccessSparseVector, etc.) to correctly read them in with SequenceReader for inputting to Mahout's built in Dunn Clustering Index.